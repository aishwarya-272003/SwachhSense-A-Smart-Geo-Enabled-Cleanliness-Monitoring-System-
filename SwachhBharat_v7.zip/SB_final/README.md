# 🌿 Swachh Bharat Mission – Dynamic Multi-City Version

## What Was Changed

| Area | Before | After |
|------|--------|-------|
| Location | Hardcoded Rabakavi boundary box | Auto-detects ANY city via GPS/IP |
| Ward Data | Static Rabakavi ward list | Loads dynamically from JSON/DB/OSM |
| Coverage Check | `if not Rabakavi: "Outside Coverage Area"` | `if wards found for city: show them` |
| Database | Single-city schema | Multi-city with `city` column everywhere |
| Cities | 1 (Rabakavi) | Unlimited |

---

## Folder Structure

```
SwachhBharat/
├── app.py                          # Main Flask app (modified)
├── requirements.txt
├── .env.example
│
├── routes/
│   ├── __init__.py
│   ├── user_routes.py              # Modified – dynamic ward loading
│   ├── staff_routes.py             # Modified – multi-city dashboard
│   ├── worker_routes.py
│   ├── central_routes.py
│   └── geo_routes.py               # ★ NEW – location API endpoints
│
├── utils/
│   ├── __init__.py
│   └── geo_utils.py                # ★ NEW – core location logic
│
├── database/
│   └── schema.sql                  # ★ UPDATED – multi-city schema
│
├── geojson/
│   └── wards/                      # ★ NEW folder – per-city ward JSON
│       ├── belagavi.json
│       ├── mysuru.json
│       ├── rabakavi-banhatti.json
│       └── <add any city>.json
│
└── templates/
    ├── home.html
    ├── user/
    │   └── user_form.html          # ★ UPDATED – location detection UI
    ├── staff/
    │   ├── login.html
    │   └── admin_dashboard.html    # ★ UPDATED – multi-city filter
    ├── worker/
    │   ├── worker_login.html
    │   └── worker_dashboard.html
    └── central/
        ├── central_login.html
        └── central_dashboard.html
```

---

## Installation

### Prerequisites
- Python 3.10+
- MySQL 8.0+
- pip

### Step 1 – Clone / Extract Project
```bash
unzip SwachhBharat-dynamic.zip
cd SwachhBharat
```

### Step 2 – Create Virtual Environment
```bash
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
```

### Step 3 – Install Dependencies
```bash
pip install -r requirements.txt
```

> **Note on mysqlclient on Ubuntu/Debian:**
> ```bash
> sudo apt-get install python3-dev default-libmysqlclient-dev build-essential
> pip install mysqlclient
> ```

### Step 4 – Configure Environment
```bash
cp .env.example .env
nano .env  # Fill in your MySQL credentials
```

`.env` contents:
```
SECRET_KEY=swachh-bharat-secret-2024
MYSQL_HOST=localhost
MYSQL_USER=root
MYSQL_PASSWORD=your_password
MYSQL_DB=swachh_bharat
```

### Step 5 – Setup Database
```bash
mysql -u root -p < database/schema.sql
```

This creates:
- `swachh_bharat` database
- `wards` table (with city column)
- `complaints` table (with city, lat/lon)
- `staff` table
- `workers` table
- Sample data for Belagavi, Mysuru, Rabakavi

### Step 6 – Run the Application
```bash
python app.py
```

Visit: **http://localhost:5000**

---

## Testing for Different Cities

### Test Belagavi
1. Open http://localhost:5000/user/form
2. Allow location (if you're in Belagavi) OR click "Change City" → Select "Belagavi"
3. Wards load automatically ✅

### Test Mysuru
1. Click "Change City" → Select "Mysuru (Mysore)"
2. 10 Mysuru wards appear in dropdown ✅

### Test via API
```bash
# Get wards for any city
curl http://localhost:5000/geo/wards/belagavi

# Detect city from coordinates
curl -X POST http://localhost:5000/geo/detect-city \
  -H "Content-Type: application/json" \
  -d '{"latitude": 15.8497, "longitude": 74.4977}'

# Check coverage
curl "http://localhost:5000/geo/coverage?lat=15.85&lon=74.50"

# List all cities with ward data
curl http://localhost:5000/geo/cities
```

---

## Adding Ward Data for a New City

### Method A – JSON File (Fastest)
Create `geojson/wards/<cityname>.json`:
```json
[
  {"ward_id": 1, "ward_name": "Ward 1 – Area Name", "area_name": "Area Name", "pincode": "590001"},
  {"ward_id": 2, "ward_name": "Ward 2 – Another Area", "area_name": "Another Area", "pincode": "590002"}
]
```
City name must be lowercase (e.g., `hubballi-dharwad.json`, `mangaluru.json`).

### Method B – Database INSERT
```sql
USE swachh_bharat;
INSERT INTO wards (ward_name, area_name, city, pincode) VALUES
('Ward 1 – Old Town', 'Old Town', 'bidar', '585401'),
('Ward 2 – New Town', 'New Town', 'bidar', '585401');
```

### Method C – Automatic from OpenStreetMap
The app auto-fetches from OpenStreetMap if no local data exists.
Just visit `/geo/wards/<cityname>` for any city name — it queries OSM live.

---

## New API Endpoints (geo_routes.py)

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/geo/detect-city` | coords or IP → city name |
| GET  | `/geo/wards/<city>` | city → ward list |
| GET  | `/geo/coverage?lat=&lon=` | GPS → coverage status |
| GET  | `/geo/cities` | list all supported cities |
| POST | `/geo/set-city` | manually set city in session |

---

## New Key Functions (utils/geo_utils.py)

```python
detect_city_from_coords(lat, lon)  # GPS → city name (OSM Nominatim)
detect_city_from_ip()              # IP → city name (ipinfo.io)
get_ward_data(city_name)           # city → ward list (JSON/DB/OSM)
check_coverage(lat, lon)           # GPS → coverage status
get_supported_cities()             # list cities with local data
normalize_city("Belgaum")         # → "belagavi" (alias resolution)
```

---

## Required External APIs

| API | Key Required | Used For |
|-----|-------------|---------|
| OpenStreetMap Nominatim | ❌ No | Reverse geocoding (GPS → city) |
| ipinfo.io | ❌ No (basic) | IP-based city detection |
| Overpass API (OSM) | ❌ No | Fetching ward boundaries |

> No paid APIs required! All APIs used are free.
>
> **Optional:** For production at scale, get a free API key from ipinfo.io (50k requests/month free).

---

## Ward JSON Format

```json
[
  {
    "ward_id":   1,
    "ward_name": "Ward 1 – Shivaji Nagar",
    "area_name": "Shivaji Nagar",
    "pincode":   "590001"
  }
]
```

Fields:
- `ward_id` – unique integer
- `ward_name` – display name shown in dropdown
- `area_name` – area/locality name
- `pincode` – 6-digit PIN code (optional)

---

## Database Schema Changes Summary

```sql
-- ADDED city column to wards:
ALTER TABLE wards ADD COLUMN city VARCHAR(100) NOT NULL;

-- ADDED city, latitude, longitude to complaints:
ALTER TABLE complaints ADD COLUMN city VARCHAR(100) NOT NULL;
ALTER TABLE complaints ADD COLUMN latitude DECIMAL(10,7);
ALTER TABLE complaints ADD COLUMN longitude DECIMAL(10,7);

-- ADDED city to staff and workers:
ALTER TABLE staff ADD COLUMN city VARCHAR(100);
ALTER TABLE workers ADD COLUMN city VARCHAR(100);
```

---

## Staff Login Credentials (Default)

| Username | Password | City |
|----------|----------|------|
| admin_blg | admin123 | Belagavi |
| admin_mys | admin123 | Mysuru |
| admin_rbk | admin123 | Rabakavi-Banhatti |

> Change passwords immediately in production!
> `UPDATE staff SET password = MD5('your_new_password') WHERE username = 'admin_blg';`

---

## How Location Detection Works

```
User opens form
     │
     ▼
Browser Geolocation API
     │
  ┌──┴──────────────────────┐
  │ Allowed                 │ Denied
  ▼                         ▼
GPS coords            IP-based detection
     │                (ipinfo.io)
     ▼                      │
OSM Nominatim ←─────────────┘
(reverse geocode)
     │
     ▼
City name detected
     │
     ▼
Load wards from:
  1. geojson/wards/<city>.json  (fastest)
  2. MySQL database             (if configured)
  3. OpenStreetMap Overpass API (live fallback)
     │
     ▼
Ward dropdown populated ✅
```

---

## Expanding to All of India

To support cities outside Karnataka, simply:

1. Add ward JSON files to `geojson/wards/` (e.g., `pune.json`, `mumbai.json`)
2. Add city options to the manual dropdown in `user_form.html`
3. Or let OpenStreetMap auto-fetch (works for any city worldwide)

The code has **no geographic restrictions** — it works globally.
