"""
utils/geo_utils.py
==================
DYNAMIC Location & Ward Detection Utilities

BEFORE (hardcoded):
    RABAKAVI_BOUNDS = {"lat_min": 16.01, "lat_max": 16.06, ...}
    if not in RABAKAVI_BOUNDS: return "Outside Coverage Area"

AFTER (dynamic):
    city = detect_city_from_coords(lat, lon)   # any city
    wards = get_ward_data(city)                # fetches dynamically
"""

import requests
from flask import current_app
import json
import os

# ─────────────────────────────────────────────────────────────────────────────
# 1. CITY DETECTION  (replaces hardcoded Rabakavi boundary check)
# ─────────────────────────────────────────────────────────────────────────────

def detect_city_from_coords(latitude: float, longitude: float) -> dict:
    """
    Reverse-geocode lat/lon → city name using OpenStreetMap Nominatim.
    No API key required.

    Returns:
        {
          "city":    "Belagavi",
          "district": "Belagavi",
          "state":   "Karnataka",
          "country": "India",
          "display_name": "...",
          "found":   True
        }
    """
    try:
        url = "https://nominatim.openstreetmap.org/reverse"
        params = {
            "lat":    latitude,
            "lon":    longitude,
            "format": "json",
            "zoom":   10,          # city-level detail
            "addressdetails": 1,
        }
        headers = {"User-Agent": "SwachhBharat-App/1.0"}
        resp = requests.get(url, params=params, headers=headers, timeout=5)
        resp.raise_for_status()
        data = resp.json()

        addr = data.get("address", {})
        city = (
            addr.get("city") or
            addr.get("town") or
            addr.get("village") or
            addr.get("county") or
            "Unknown"
        )
        return {
            "city":         city,
            "district":     addr.get("county", ""),
            "state":        addr.get("state", ""),
            "country":      addr.get("country", ""),
            "display_name": data.get("display_name", ""),
            "found":        True,
        }
    except requests.exceptions.ConnectionError:
        return {"city": "Unknown", "found": False, "error": "Network unavailable"}
    except Exception as e:
        return {"city": "Unknown", "found": False, "error": str(e)}


def detect_city_from_ip() -> dict:
    """
    IP-based city detection using ipinfo.io (no key needed for basic use).
    Fallback when browser geolocation is denied.

    Returns same dict structure as detect_city_from_coords().
    """
    try:
        resp = requests.get("https://ipinfo.io/json", timeout=5)
        resp.raise_for_status()
        data = resp.json()

        city = data.get("city", "Unknown")
        region = data.get("region", "")

        # Parse lat/lon if provided
        loc = data.get("loc", "0,0").split(",")
        latitude  = float(loc[0]) if len(loc) == 2 else 0.0
        longitude = float(loc[1]) if len(loc) == 2 else 0.0

        return {
            "city":      city,
            "district":  region,
            "state":     region,
            "country":   data.get("country", ""),
            "latitude":  latitude,
            "longitude": longitude,
            "found":     True,
        }
    except Exception as e:
        return {"city": "Unknown", "found": False, "error": str(e)}


# ─────────────────────────────────────────────────────────────────────────────
# 2. WARD DATA LOADER  (replaces hardcoded Rabakavi ward list)
# ─────────────────────────────────────────────────────────────────────────────

# Local ward JSON cache directory
WARD_DATA_DIR = os.path.join(os.path.dirname(__file__), '..', 'geojson', 'wards')

# Built-in city aliases  (handles spelling variants)
CITY_ALIASES = {
    "belgaum":    "belagavi",
    "belgavi":    "belagavi",
    "hubli":      "hubballi",
    "dharwad":    "hubballi-dharwad",
    "mysore":     "mysuru",
    "mangalore":  "mangaluru",
    "shimoga":    "shivamogga",
    "gulbarga":   "kalaburagi",
    "bijapur":    "vijayapura",
    "rabakavi":   "rabakavi-banhatti",
    "jamkhandi":  "jamkhandi",
}


def normalize_city(city_name: str) -> str:
    """Lowercase + alias resolution."""
    key = city_name.lower().strip()
    return CITY_ALIASES.get(key, key)


def get_ward_data(city_name: str) -> dict:
    """
    Main function: returns ward list for any city.

    Priority order:
      1. Local JSON file  (geojson/wards/<city>.json)
      2. MySQL database   (wards table with city column)
      3. OpenStreetMap Overpass API  (live fetch)
      4. Not found → meaningful error

    Returns:
        {
          "city":   "belagavi",
          "wards": [
            {"ward_id": 1, "ward_name": "Ward 1", "area": "...", "pincode": "..."},
            ...
          ],
          "source": "local_json" | "database" | "overpass" | "not_found",
          "found":  True | False
        }
    """
    city_key = normalize_city(city_name)

    # ── Strategy 1: Local JSON file ──────────────────────────────────────────
    result = _load_ward_from_json(city_key)
    if result["found"]:
        return result

    # ── Strategy 2: Database ─────────────────────────────────────────────────
    result = _load_ward_from_db(city_key)
    if result["found"]:
        return result

    # ── Strategy 3: OpenStreetMap Overpass API ───────────────────────────────
    result = _load_ward_from_overpass(city_key)
    if result["found"]:
        # Cache it locally for next time
        _save_ward_to_json(city_key, result["wards"])
        return result

    # ── Not found ────────────────────────────────────────────────────────────
    return {
        "city":   city_key,
        "wards":  [],
        "source": "not_found",
        "found":  False,
        "error":  f"Ward data not available for '{city_name}'. "
                  "You can add it via Admin panel or upload a ward JSON."
    }


# ─────────────────────────────────────────────────────────────────────────────
# Internal helpers
# ─────────────────────────────────────────────────────────────────────────────

def _load_ward_from_json(city_key: str) -> dict:
    path = os.path.join(WARD_DATA_DIR, f"{city_key}.json")
    if not os.path.exists(path):
        return {"found": False}
    try:
        with open(path, encoding='utf-8') as f:
            wards = json.load(f)
        return {"city": city_key, "wards": wards, "source": "local_json", "found": True}
    except Exception as e:
        return {"found": False, "error": str(e)}


def _load_ward_from_db(city_key: str) -> dict:
    """Load wards from MySQL. Requires app context."""
    try:
        from flask import current_app
        from flask_mysqldb import MySQL
        # Lazy import to avoid circular dependency
        from app import mysql
        cur = mysql.connection.cursor()
        cur.execute(
            "SELECT ward_id, ward_name, area_name, pincode, boundary_coordinates "
            "FROM wards WHERE LOWER(city) = %s ORDER BY ward_id",
            (city_key,)
        )
        rows = cur.fetchall()
        cur.close()
        if rows:
            return {"city": city_key, "wards": list(rows), "source": "database", "found": True}
        return {"found": False}
    except Exception:
        return {"found": False}


def _load_ward_from_overpass(city_key: str) -> dict:
    """
    Fetch ward/neighbourhood boundaries from OpenStreetMap Overpass API.
    Works for ANY city in the world.
    """
    try:
        # Search for administrative boundaries (level 8-10 = ward/neighbourhood)
        query = f"""
        [out:json][timeout:25];
        area["name"~"{city_key}",i]["admin_level"~"[4-8]"]->.searchArea;
        (
          relation["admin_level"~"[9-10]"](area.searchArea);
          node["place"~"suburb|neighbourhood|quarter"](area.searchArea);
        );
        out body;
        """
        resp = requests.post(
            "https://overpass-api.de/api/interpreter",
            data={"data": query},
            timeout=20
        )
        resp.raise_for_status()
        data = resp.json()
        elements = data.get("elements", [])

        wards = []
        for i, el in enumerate(elements, start=1):
            name = (el.get("tags") or {}).get("name") or f"Ward {i}"
            wards.append({
                "ward_id":   i,
                "ward_name": name,
                "area_name": name,
                "pincode":   "",
                "osm_id":    el.get("id"),
            })

        if wards:
            return {"city": city_key, "wards": wards, "source": "overpass", "found": True}
        return {"found": False}

    except requests.exceptions.ConnectionError:
        return {"found": False, "error": "No internet connection"}
    except Exception as e:
        return {"found": False, "error": str(e)}


def _save_ward_to_json(city_key: str, wards: list):
    """Cache ward data locally to avoid repeated API calls."""
    os.makedirs(WARD_DATA_DIR, exist_ok=True)
    path = os.path.join(WARD_DATA_DIR, f"{city_key}.json")
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(wards, f, ensure_ascii=False, indent=2)
    except Exception:
        pass  # Non-critical; just cache failure


# ─────────────────────────────────────────────────────────────────────────────
# 3. COVERAGE CHECK  (replaces hardcoded boundary polygon check)
# ─────────────────────────────────────────────────────────────────────────────

def check_coverage(latitude: float, longitude: float) -> dict:
    """
    BEFORE: Hard check against Rabakavi bounding box → "Outside Coverage Area"
    AFTER:  Detect city → check if we have ward data → return status

    Returns:
        {
          "covered": True/False,
          "city":    "Belagavi",
          "message": "...",
          "ward_count": 58
        }
    """
    location = detect_city_from_coords(latitude, longitude)

    if not location["found"]:
        return {
            "covered": False,
            "city":    "Unknown",
            "message": "Could not determine your city. Please select manually.",
        }

    city = location["city"]
    ward_data = get_ward_data(city)

    if ward_data["found"]:
        return {
            "covered":    True,
            "city":       city,
            "state":      location.get("state", ""),
            "message":    f"Coverage available for {city}",
            "ward_count": len(ward_data["wards"]),
            "source":     ward_data["source"],
        }
    else:
        return {
            "covered": False,
            "city":    city,
            "state":   location.get("state", ""),
            "message": f"Ward data not yet available for {city}. "
                       f"You can still register; data will be added soon.",
        }


# ─────────────────────────────────────────────────────────────────────────────
# 4. LIST SUPPORTED CITIES
# ─────────────────────────────────────────────────────────────────────────────

def get_supported_cities() -> list:
    """Return list of cities that have local ward JSON files."""
    cities = []
    if os.path.exists(WARD_DATA_DIR):
        for f in os.listdir(WARD_DATA_DIR):
            if f.endswith('.json'):
                cities.append(f.replace('.json', '').title())
    return sorted(cities)
