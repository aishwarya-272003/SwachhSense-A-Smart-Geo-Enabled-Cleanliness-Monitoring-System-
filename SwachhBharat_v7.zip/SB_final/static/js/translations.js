// ── Swachh Bharat Mission – Multi-language Support ──────────────
// Supported: en (English), hi (Hindi), kn (Kannada)

const TRANSLATIONS = {
  en: {
    // Common
    site_name: "Swachh Bharat Mission",
    home: "Home",
    about: "About",
    register_complaint: "Register Complaint",
    staff_login: "Staff Login",
    worker_login: "Worker Login",
    change_city: "Change City",

    // Home page
    hero_subtitle: "Report sanitation issues in your city. We'll make sure they get resolved.",
    btn_register: "📝 Register Complaint",
    btn_staff: "🔐 Staff Login",
    btn_worker: "👷 Worker Login",
    feat_location_title: "Auto Location Detection",
    feat_location_desc: "Automatically detects your city and loads ward information. No manual setup needed.",
    feat_everywhere_title: "Works Everywhere",
    feat_everywhere_desc: "Supports Belagavi, Mysuru, Mangaluru, and all Karnataka cities. Expandable to all of India.",
    feat_fast_title: "Fast Resolution",
    feat_fast_desc: "Complaints are assigned to local ward workers for quick resolution and tracking.",

    // About page
    about_title: "About Swachh Bharat Mission",
    about_subtitle: "A digital platform to report and resolve sanitation issues across India",
    mission_title: "🌿 Our Mission",
    mission_p1: "Swachh Bharat Mission is a flagship program of the Government of India aimed at making India clean and open defecation free. This digital platform extends that mission by enabling citizens to report sanitation issues directly to local municipal authorities.",
    mission_p2: "Our system automatically detects your location and connects you with the right ward office — no matter which city you're in.",
    features_title: "⚡ Key Features",
    feat_auto_title: "Auto Location Detection",
    feat_auto_desc: "Detects your city automatically",
    feat_city_title: "Multi-City Support",
    feat_city_desc: "Works for all Karnataka cities",
    feat_easy_title: "Easy Reporting",
    feat_easy_desc: "Simple complaint registration",
    feat_resolve_title: "Fast Resolution",
    feat_resolve_desc: "Track complaint status",
    contact_title: "📞 Contact",
    contact_p1: "For support or queries, please contact your local municipal corporation or the Swachh Bharat helpline.",
    contact_helpline: "National Helpline:",

    // Complaint Form
    form_title: "Register Sanitation Complaint",
    detecting_location: "Detecting your location...",
    complaint_form_header: "📝 Complaint Registration Form",
    label_name: "Full Name *",
    placeholder_name: "Enter your full name",
    label_phone: "Phone Number *",
    label_ward: "Ward *",
    select_ward: "-- Select Ward --",
    loading_wards: "⏳ Loading wards...",
    label_complaint: "Complaint / Issue *",
    placeholder_complaint: "Describe the issue (e.g. garbage not collected, open drain, etc.)",
    label_photos: "Upload Photos",
    photos_optional: "(optional, max 5 images)",
    upload_text: "Click to upload or drag & drop photos",
    upload_hint: "JPG, PNG, WEBP — Max 5MB each — Up to 5 photos",
    btn_submit: "📤 Submit Complaint",
    select_city_title: "🏙️ Select Your City",
    select_city_placeholder: "-- Select City --",
    btn_confirm: "✓ Confirm",
    btn_cancel: "Cancel",
    please_select_city: "Please select a city.",
    max_images_alert: "Maximum 5 images allowed.",
    not_image_alert: "is not an image.",
    size_limit_alert: "exceeds 5MB limit.",
    photo_selected_single: "photo selected",
    photo_selected_plural: "photos selected",
    auto_detected: "Auto-detected",
    from_session: "From session",
    please_select_manually: "Please select manually",
  },

  hi: {
    // Common
    site_name: "स्वच्छ भारत मिशन",
    home: "होम",
    about: "परिचय",
    register_complaint: "शिकायत दर्ज करें",
    staff_login: "स्टाफ लॉगिन",
    worker_login: "कर्मचारी लॉगिन",
    change_city: "शहर बदलें",

    // Home page
    hero_subtitle: "अपने शहर में स्वच्छता संबंधी समस्याएँ रिपोर्ट करें। हम उन्हें हल करेंगे।",
    btn_register: "📝 शिकायत दर्ज करें",
    btn_staff: "🔐 स्टाफ लॉगिन",
    btn_worker: "👷 कर्मचारी लॉगिन",
    feat_location_title: "स्वचालित स्थान पहचान",
    feat_location_desc: "आपके शहर को स्वचालित रूप से पहचानता है और वार्ड जानकारी लोड करता है। कोई मैन्युअल सेटअप आवश्यक नहीं।",
    feat_everywhere_title: "हर जगह काम करता है",
    feat_everywhere_desc: "बेलगावी, मैसूरु, मंगलुरु और सभी कर्नाटक शहरों में काम करता है। पूरे भारत में विस्तार योग्य।",
    feat_fast_title: "तेज़ समाधान",
    feat_fast_desc: "शिकायतें स्थानीय वार्ड कर्मचारियों को त्वरित समाधान और ट्रैकिंग के लिए सौंपी जाती हैं।",

    // About page
    about_title: "स्वच्छ भारत मिशन के बारे में",
    about_subtitle: "पूरे भारत में स्वच्छता संबंधी समस्याओं को रिपोर्ट और हल करने का एक डिजिटल मंच",
    mission_title: "🌿 हमारा मिशन",
    mission_p1: "स्वच्छ भारत मिशन भारत सरकार का एक प्रमुख कार्यक्रम है जो भारत को स्वच्छ और खुले में शौच मुक्त बनाने के उद्देश्य से है। यह डिजिटल प्लेटफॉर्म नागरिकों को सीधे स्थानीय नगरीय अधिकारियों को स्वच्छता संबंधी समस्याएं रिपोर्ट करने में सक्षम बनाकर उस मिशन को आगे बढ़ाता है।",
    mission_p2: "हमारी प्रणाली स्वचालित रूप से आपका स्थान पहचानती है और आपको सही वार्ड कार्यालय से जोड़ती है — चाहे आप किसी भी शहर में हों।",
    features_title: "⚡ मुख्य विशेषताएं",
    feat_auto_title: "स्वचालित स्थान पहचान",
    feat_auto_desc: "आपके शहर को स्वचालित रूप से पहचानता है",
    feat_city_title: "बहु-शहर समर्थन",
    feat_city_desc: "सभी कर्नाटक शहरों के लिए काम करता है",
    feat_easy_title: "आसान रिपोर्टिंग",
    feat_easy_desc: "सरल शिकायत पंजीकरण",
    feat_resolve_title: "तेज़ समाधान",
    feat_resolve_desc: "शिकायत स्थिति ट्रैक करें",
    contact_title: "📞 संपर्क",
    contact_p1: "सहायता या प्रश्नों के लिए, कृपया अपनी स्थानीय नगर निगम या स्वच्छ भारत हेल्पलाइन से संपर्क करें।",
    contact_helpline: "राष्ट्रीय हेल्पलाइन:",

    // Complaint Form
    form_title: "स्वच्छता शिकायत दर्ज करें",
    detecting_location: "आपका स्थान पहचाना जा रहा है...",
    complaint_form_header: "📝 शिकायत पंजीकरण फॉर्म",
    label_name: "पूरा नाम *",
    placeholder_name: "अपना पूरा नाम दर्ज करें",
    label_phone: "फोन नंबर *",
    label_ward: "वार्ड *",
    select_ward: "-- वार्ड चुनें --",
    loading_wards: "⏳ वार्ड लोड हो रहे हैं...",
    label_complaint: "शिकायत / समस्या *",
    placeholder_complaint: "समस्या का विवरण दें (जैसे कचरा नहीं उठाया, खुला नाला, आदि)",
    label_photos: "फ़ोटो अपलोड करें",
    photos_optional: "(वैकल्पिक, अधिकतम 5 चित्र)",
    upload_text: "अपलोड करने के लिए क्लिक करें या फ़ोटो खींचें और छोड़ें",
    upload_hint: "JPG, PNG, WEBP — प्रत्येक अधिकतम 5MB — 5 फ़ोटो तक",
    btn_submit: "📤 शिकायत जमा करें",
    select_city_title: "🏙️ अपना शहर चुनें",
    select_city_placeholder: "-- शहर चुनें --",
    btn_confirm: "✓ पुष्टि करें",
    btn_cancel: "रद्द करें",
    please_select_city: "कृपया एक शहर चुनें।",
    max_images_alert: "अधिकतम 5 चित्रों की अनुमति है।",
    not_image_alert: "एक चित्र नहीं है।",
    size_limit_alert: "5MB की सीमा से अधिक है।",
    photo_selected_single: "फ़ोटो चुनी गई",
    photo_selected_plural: "फ़ोटो चुनी गईं",
    auto_detected: "स्वचालित रूप से पहचाना गया",
    from_session: "सत्र से",
    please_select_manually: "कृपया मैन्युअल रूप से चुनें",
  },

  kn: {
    // Common
    site_name: "ಸ್ವಚ್ಛ ಭಾರತ ಮಿಷನ್",
    home: "ಮನೆ",
    about: "ಪರಿಚಯ",
    register_complaint: "ದೂರು ನೋಂದಾಯಿಸಿ",
    staff_login: "ಸಿಬ್ಬಂದಿ ಲಾಗಿನ್",
    worker_login: "ಕಾರ್ಮಿಕ ಲಾಗಿನ್",
    change_city: "ನಗರ ಬದಲಾಯಿಸಿ",

    // Home page
    hero_subtitle: "ನಿಮ್ಮ ನಗರದಲ್ಲಿ ಸ್ವಚ್ಛತೆ ಸಮಸ್ಯೆಗಳನ್ನು ವರದಿ ಮಾಡಿ. ನಾವು ಅವುಗಳನ್ನು ಪರಿಹರಿಸುತ್ತೇವೆ.",
    btn_register: "📝 ದೂರು ನೋಂದಾಯಿಸಿ",
    btn_staff: "🔐 ಸಿಬ್ಬಂದಿ ಲಾಗಿನ್",
    btn_worker: "👷 ಕಾರ್ಮಿಕ ಲಾಗಿನ್",
    feat_location_title: "ಸ್ವಯಂ ಸ್ಥಳ ಪತ್ತೆ",
    feat_location_desc: "ನಿಮ್ಮ ನಗರವನ್ನು ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಪತ್ತೆಹಚ್ಚಿ ವಾರ್ಡ್ ಮಾಹಿತಿ ಲೋಡ್ ಮಾಡುತ್ತದೆ. ಕೈಯಿಂದ ಸೆಟಪ್ ಅಗತ್ಯವಿಲ್ಲ.",
    feat_everywhere_title: "ಎಲ್ಲೆಡೆ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ",
    feat_everywhere_desc: "ಬೆಳಗಾವಿ, ಮೈಸೂರು, ಮಂಗಳೂರು ಮತ್ತು ಎಲ್ಲ ಕರ್ನಾಟಕ ನಗರಗಳಲ್ಲಿ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ. ಇಡೀ ಭಾರತಕ್ಕೆ ವಿಸ್ತರಿಸಬಹುದು.",
    feat_fast_title: "ತ್ವರಿತ ಪರಿಹಾರ",
    feat_fast_desc: "ದೂರುಗಳನ್ನು ಸ್ಥಳೀಯ ವಾರ್ಡ್ ಕಾರ್ಮಿಕರಿಗೆ ತ್ವರಿತ ಪರಿಹಾರ ಮತ್ತು ಟ್ರ್ಯಾಕಿಂಗ್‌ಗಾಗಿ ನಿಯೋಜಿಸಲಾಗುತ್ತದೆ.",

    // About page
    about_title: "ಸ್ವಚ್ಛ ಭಾರತ ಮಿಷನ್ ಬಗ್ಗೆ",
    about_subtitle: "ಭಾರತದಾದ್ಯಂತ ಸ್ವಚ್ಛತೆ ಸಮಸ್ಯೆಗಳನ್ನು ವರದಿ ಮಾಡಲು ಮತ್ತು ಪರಿಹರಿಸಲು ಡಿಜಿಟಲ್ ವೇದಿಕೆ",
    mission_title: "🌿 ನಮ್ಮ ಮಿಷನ್",
    mission_p1: "ಸ್ವಚ್ಛ ಭಾರತ ಮಿಷನ್ ಭಾರತ ಸರ್ಕಾರದ ಒಂದು ಪ್ರಮುಖ ಕಾರ್ಯಕ್ರಮವಾಗಿದ್ದು, ಭಾರತವನ್ನು ಸ್ವಚ್ಛ ಮತ್ತು ಬಯಲು ಶೌಚ ಮುಕ್ತಗೊಳಿಸುವ ಗುರಿ ಹೊಂದಿದೆ. ಈ ಡಿಜಿಟಲ್ ವೇದಿಕೆ ನಾಗರಿಕರಿಗೆ ನೇರವಾಗಿ ಸ್ಥಳೀಯ ನಗರ ಪ್ರಾಧಿಕಾರಗಳಿಗೆ ಸ್ವಚ್ಛತೆ ಸಮಸ್ಯೆಗಳನ್ನು ವರದಿ ಮಾಡಲು ಸಕ್ರಿಯಗೊಳಿಸುವ ಮೂಲಕ ಆ ಮಿಷನ್ ಅನ್ನು ವಿಸ್ತರಿಸುತ್ತದೆ.",
    mission_p2: "ನಮ್ಮ ವ್ಯವಸ್ಥೆ ಸ್ವಯಂಚಾಲಿತವಾಗಿ ನಿಮ್ಮ ಸ್ಥಳವನ್ನು ಪತ್ತೆಹಚ್ಚಿ ನಿಮ್ಮನ್ನು ಸರಿಯಾದ ವಾರ್ಡ್ ಕಚೇರಿಗೆ ಸಂಪರ್ಕಿಸುತ್ತದೆ — ನೀವು ಯಾವ ನಗರದಲ್ಲಿ ಇದ್ದರೂ ಸರಿ.",
    features_title: "⚡ ಮುಖ್ಯ ವೈಶಿಷ್ಟ್ಯಗಳು",
    feat_auto_title: "ಸ್ವಯಂ ಸ್ಥಳ ಪತ್ತೆ",
    feat_auto_desc: "ನಿಮ್ಮ ನಗರವನ್ನು ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಪತ್ತೆಹಚ್ಚುತ್ತದೆ",
    feat_city_title: "ಬಹು-ನಗರ ಬೆಂಬಲ",
    feat_city_desc: "ಎಲ್ಲ ಕರ್ನಾಟಕ ನಗರಗಳಿಗೆ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ",
    feat_easy_title: "ಸುಲಭ ವರದಿ",
    feat_easy_desc: "ಸರಳ ದೂರು ನೋಂದಣಿ",
    feat_resolve_title: "ತ್ವರಿತ ಪರಿಹಾರ",
    feat_resolve_desc: "ದೂರಿನ ಸ್ಥಿತಿ ಟ್ರ್ಯಾಕ್ ಮಾಡಿ",
    contact_title: "📞 ಸಂಪರ್ಕ",
    contact_p1: "ಸಹಾಯ ಅಥವಾ ಪ್ರಶ್ನೆಗಳಿಗಾಗಿ, ದಯವಿಟ್ಟು ನಿಮ್ಮ ಸ್ಥಳೀಯ ನಗರ ನಿಗಮ ಅಥವಾ ಸ್ವಚ್ಛ ಭಾರತ ಹೆಲ್ಪ್‌ಲೈನ್ ಅನ್ನು ಸಂಪರ್ಕಿಸಿ.",
    contact_helpline: "ರಾಷ್ಟ್ರೀಯ ಹೆಲ್ಪ್‌ಲೈನ್:",

    // Complaint Form
    form_title: "ಸ್ವಚ್ಛತೆ ದೂರು ನೋಂದಾಯಿಸಿ",
    detecting_location: "ನಿಮ್ಮ ಸ್ಥಳ ಪತ್ತೆಯಾಗುತ್ತಿದೆ...",
    complaint_form_header: "📝 ದೂರು ನೋಂದಣಿ ಫಾರ್ಮ್",
    label_name: "ಪೂರ್ಣ ಹೆಸರು *",
    placeholder_name: "ನಿಮ್ಮ ಪೂರ್ಣ ಹೆಸರು ನಮೂದಿಸಿ",
    label_phone: "ಫೋನ್ ಸಂಖ್ಯೆ *",
    label_ward: "ವಾರ್ಡ್ *",
    select_ward: "-- ವಾರ್ಡ್ ಆಯ್ಕೆ ಮಾಡಿ --",
    loading_wards: "⏳ ವಾರ್ಡ್‌ಗಳನ್ನು ಲೋಡ್ ಮಾಡಲಾಗುತ್ತಿದೆ...",
    label_complaint: "ದೂರು / ಸಮಸ್ಯೆ *",
    placeholder_complaint: "ಸಮಸ್ಯೆಯನ್ನು ವಿವರಿಸಿ (ಉದಾ. ಕಸ ಸಂಗ್ರಹಿಸಲಿಲ್ಲ, ತೆರೆದ ಚರಂಡಿ, ಇತ್ಯಾದಿ)",
    label_photos: "ಫೋಟೋಗಳನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಿ",
    photos_optional: "(ಐಚ್ಛಿಕ, ಗರಿಷ್ಠ 5 ಚಿತ್ರಗಳು)",
    upload_text: "ಅಪ್‌ಲೋಡ್ ಮಾಡಲು ಕ್ಲಿಕ್ ಮಾಡಿ ಅಥವಾ ಫೋಟೋಗಳನ್ನು ಎಳೆದು ಬಿಡಿ",
    upload_hint: "JPG, PNG, WEBP — ತಲಾ ಗರಿಷ್ಠ 5MB — 5 ಫೋಟೋಗಳವರೆಗೆ",
    btn_submit: "📤 ದೂರು ಸಲ್ಲಿಸಿ",
    select_city_title: "🏙️ ನಿಮ್ಮ ನಗರ ಆಯ್ಕೆ ಮಾಡಿ",
    select_city_placeholder: "-- ನಗರ ಆಯ್ಕೆ ಮಾಡಿ --",
    btn_confirm: "✓ ದೃಢೀಕರಿಸಿ",
    btn_cancel: "ರದ್ದು ಮಾಡಿ",
    please_select_city: "ದಯವಿಟ್ಟು ನಗರ ಆಯ್ಕೆ ಮಾಡಿ.",
    max_images_alert: "ಗರಿಷ್ಠ 5 ಚಿತ್ರಗಳು ಮಾತ್ರ ಅನುಮತಿಸಲಾಗಿದೆ.",
    not_image_alert: "ಒಂದು ಚಿತ್ರವಲ್ಲ.",
    size_limit_alert: "5MB ಮಿತಿಯನ್ನು ಮೀರಿದೆ.",
    photo_selected_single: "ಫೋಟೋ ಆಯ್ಕೆಯಾಗಿದೆ",
    photo_selected_plural: "ಫೋಟೋಗಳು ಆಯ್ಕೆಯಾಗಿವೆ",
    auto_detected: "ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಪತ್ತೆಯಾಗಿದೆ",
    from_session: "ಸೆಷನ್‌ನಿಂದ",
    please_select_manually: "ದಯವಿಟ್ಟು ಕೈಯಿಂದ ಆಯ್ಕೆ ಮಾಡಿ",
  }
};

// ── Language Switcher Logic ──────────────────────────────────────

let currentLang = localStorage.getItem('sbm_lang') || 'en';

function t(key) {
  return (TRANSLATIONS[currentLang] && TRANSLATIONS[currentLang][key]) ||
         (TRANSLATIONS['en'] && TRANSLATIONS['en'][key]) || key;
}

function applyTranslations(lang) {
  currentLang = lang;
  localStorage.setItem('sbm_lang', lang);

  // Update all data-i18n elements (text content)
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    el.textContent = t(key);
  });

  // Update all data-i18n-placeholder elements
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    const key = el.getAttribute('data-i18n-placeholder');
    el.placeholder = t(key);
  });

  // Update all data-i18n-html elements (innerHTML)
  document.querySelectorAll('[data-i18n-html]').forEach(el => {
    const key = el.getAttribute('data-i18n-html');
    el.innerHTML = t(key);
  });

  // Update active button state
  document.querySelectorAll('.lang-btn').forEach(btn => {
    btn.classList.toggle('active', btn.getAttribute('data-lang') === lang);
  });
}

function initLanguageSwitcher() {
  applyTranslations(currentLang);
}

// ── Additional keys added after initial version ──
// These are merged into TRANSLATIONS at runtime
(function() {
  const extra = {
    en: {
      login_username: "Username", login_password: "Password", login_btn: "Login", back_home: "← Back to Home",
      worker_id_label: "Worker ID",
      nav_dashboard: "Dashboard", nav_new_complaints: "New Complaints", nav_solved: "Solved Complaints",
      nav_staff_list: "Staff List", nav_add_staff: "Add Staff", nav_workers: "Workers",
      nav_working_staff: "Working Staff", nav_user_data: "User Data",
      logged_in_as: "Logged in as", logout: "Logout",
      stat_total: "Total Complaints", stat_pending: "Pending", stat_in_progress: "In Progress", stat_resolved: "Resolved",
      filter_city: "Filter by City:", all_cities: "All Cities", complaints_count: "complaints",
      recent_complaints: "Recent Complaints", pending_complaints: "Pending Complaints", resolved_complaints: "Resolved Complaints",
      th_name: "Name", th_phone: "Phone", th_city: "City", th_ward: "Ward", th_complaint: "Complaint",
      th_photos: "Photos", th_status: "Status", th_date: "Date", th_action: "Action", th_resolved_on: "Resolved On",
      th_username: "Username", th_role: "Role", th_actions: "Actions", th_vehicle: "Vehicle",
      no_complaints: "No complaints found.", no_pending: "No pending complaints", no_resolved: "No resolved complaints yet",
      no_staff: "No staff found", no_workers: "No workers found", no_data: "No data found", no_active_workers: "No active workers",
      all_staff: "All Staff Members", all_workers: "All Workers", all_submissions: "All Complaint Submissions",
      total: "total", records: "records",
      in_progress: "In Progress", resolve: "Resolve", edit: "Edit", delete: "Delete", save_changes: "Save Changes",
      add_staff_header: "Add New Staff Member", add_staff_btn: "Add Staff Member", edit_staff_title: "Edit Staff", edit_staff_header: "Edit Staff Member",
      field_full_name: "Full Name *", new_password_label: "New Password",
      role_inspector: "Inspector", role_supervisor: "Supervisor", role_admin: "Admin",
      add_worker: "➕ Add Worker", add_worker_header: "➕ Add New Worker", add_worker_btn: "Add Worker", worker_name: "Worker Name",
      active_workers: "Active Workers", complaints_in_progress: "Complaints In Progress", active_workers_on_duty: "Active Workers On Duty",
      worker_dashboard_title: "Worker Dashboard", welcome_msg: "Welcome back! Here are your current assignment details.",
      worker_name_label: "Worker Name", status_active: "Active", worker_status_msg: "You are on duty. Please check with your supervisor for assigned complaints in your ward.",
      central_admin_title: "🏛️ Central Admin", central_dashboard_title: "Central Dashboard – All Cities",
      supported_cities_label: "Supported Cities", view_complaints: "View Complaints →", no_cities: "No cities configured yet.",
    },
    hi: {
      login_username: "उपयोगकर्ता नाम", login_password: "पासवर्ड", login_btn: "लॉगिन", back_home: "← होम पर वापस",
      worker_id_label: "कर्मचारी ID",
      nav_dashboard: "डैशबोर्ड", nav_new_complaints: "नई शिकायतें", nav_solved: "हल की गई शिकायतें",
      nav_staff_list: "स्टाफ सूची", nav_add_staff: "स्टाफ जोड़ें", nav_workers: "कर्मचारी",
      nav_working_staff: "कार्यरत स्टाफ", nav_user_data: "उपयोगकर्ता डेटा",
      logged_in_as: "लॉग इन हैं", logout: "लॉगआउट",
      stat_total: "कुल शिकायतें", stat_pending: "लंबित", stat_in_progress: "प्रगति में", stat_resolved: "हल किया",
      filter_city: "शहर से फ़िल्टर करें:", all_cities: "सभी शहर", complaints_count: "शिकायतें",
      recent_complaints: "हाल की शिकायतें", pending_complaints: "लंबित शिकायतें", resolved_complaints: "हल की गई शिकायतें",
      th_name: "नाम", th_phone: "फोन", th_city: "शहर", th_ward: "वार्ड", th_complaint: "शिकायत",
      th_photos: "फ़ोटो", th_status: "स्थिति", th_date: "तारीख", th_action: "कार्रवाई", th_resolved_on: "हल किया गया",
      th_username: "उपयोगकर्ता नाम", th_role: "भूमिका", th_actions: "कार्रवाइयां", th_vehicle: "वाहन",
      no_complaints: "कोई शिकायत नहीं मिली।", no_pending: "कोई लंबित शिकायत नहीं", no_resolved: "अभी तक कोई हल नहीं",
      no_staff: "कोई स्टाफ नहीं मिला", no_workers: "कोई कर्मचारी नहीं मिला", no_data: "कोई डेटा नहीं मिला", no_active_workers: "कोई सक्रिय कर्मचारी नहीं",
      all_staff: "सभी स्टाफ सदस्य", all_workers: "सभी कर्मचारी", all_submissions: "सभी शिकायत सबमिशन",
      total: "कुल", records: "रिकॉर्ड",
      in_progress: "प्रगति में", resolve: "हल करें", edit: "संपादित करें", delete: "हटाएं", save_changes: "परिवर्तन सहेजें",
      add_staff_header: "नया स्टाफ सदस्य जोड़ें", add_staff_btn: "स्टाफ सदस्य जोड़ें", edit_staff_title: "स्टाफ संपादित करें", edit_staff_header: "स्टाफ सदस्य संपादित करें",
      field_full_name: "पूरा नाम *", new_password_label: "नया पासवर्ड",
      role_inspector: "निरीक्षक", role_supervisor: "पर्यवेक्षक", role_admin: "व्यवस्थापक",
      add_worker: "➕ कर्मचारी जोड़ें", add_worker_header: "➕ नया कर्मचारी जोड़ें", add_worker_btn: "कर्मचारी जोड़ें", worker_name: "कर्मचारी का नाम",
      active_workers: "सक्रिय कर्मचारी", complaints_in_progress: "प्रगति में शिकायतें", active_workers_on_duty: "ड्यूटी पर सक्रिय कर्मचारी",
      worker_dashboard_title: "कर्मचारी डैशबोर्ड", welcome_msg: "वापस स्वागत है! यहाँ आपके वर्तमान असाइनमेंट विवरण हैं।",
      worker_name_label: "कर्मचारी का नाम", status_active: "सक्रिय", worker_status_msg: "आप ड्यूटी पर हैं। अपने वार्ड में सौंपी गई शिकायतों के लिए अपने पर्यवेक्षक से जांच करें।",
      central_admin_title: "🏛️ केंद्रीय व्यवस्थापक", central_dashboard_title: "केंद्रीय डैशबोर्ड – सभी शहर",
      supported_cities_label: "समर्थित शहर", view_complaints: "शिकायतें देखें →", no_cities: "अभी तक कोई शहर कॉन्फ़िगर नहीं।",
    },
    kn: {
      login_username: "ಬಳಕೆದಾರರ ಹೆಸರು", login_password: "ಪಾಸ್‌ವರ್ಡ್", login_btn: "ಲಾಗಿನ್", back_home: "← ಮನೆಗೆ ಹಿಂತಿರುಗಿ",
      worker_id_label: "ಕಾರ್ಮಿಕ ID",
      nav_dashboard: "ಡ್ಯಾಶ್‌ಬೋರ್ಡ್", nav_new_complaints: "ಹೊಸ ದೂರುಗಳು", nav_solved: "ಪರಿಹರಿಸಿದ ದೂರುಗಳು",
      nav_staff_list: "ಸಿಬ್ಬಂದಿ ಪಟ್ಟಿ", nav_add_staff: "ಸಿಬ್ಬಂದಿ ಸೇರಿಸಿ", nav_workers: "ಕಾರ್ಮಿಕರು",
      nav_working_staff: "ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತಿರುವ ಸಿಬ್ಬಂದಿ", nav_user_data: "ಬಳಕೆದಾರ ಡೇಟಾ",
      logged_in_as: "ಲಾಗಿನ್ ಆಗಿದ್ದಾರೆ", logout: "ಲಾಗ್‌ಔಟ್",
      stat_total: "ಒಟ್ಟು ದೂರುಗಳು", stat_pending: "ಬಾಕಿ ಇದೆ", stat_in_progress: "ಪ್ರಗತಿಯಲ್ಲಿದೆ", stat_resolved: "ಪರಿಹರಿಸಲಾಗಿದೆ",
      filter_city: "ನಗರದ ಮೂಲಕ ಫಿಲ್ಟರ್:", all_cities: "ಎಲ್ಲ ನಗರಗಳು", complaints_count: "ದೂರುಗಳು",
      recent_complaints: "ಇತ್ತೀಚಿನ ದೂರುಗಳು", pending_complaints: "ಬಾಕಿ ದೂರುಗಳು", resolved_complaints: "ಪರಿಹರಿಸಿದ ದೂರುಗಳು",
      th_name: "ಹೆಸರು", th_phone: "ಫೋನ್", th_city: "ನಗರ", th_ward: "ವಾರ್ಡ್", th_complaint: "ದೂರು",
      th_photos: "ಫೋಟೋಗಳು", th_status: "ಸ್ಥಿತಿ", th_date: "ದಿನಾಂಕ", th_action: "ಕ್ರಿಯೆ", th_resolved_on: "ಪರಿಹರಿಸಿದ ದಿನಾಂಕ",
      th_username: "ಬಳಕೆದಾರರ ಹೆಸರು", th_role: "ಪಾತ್ರ", th_actions: "ಕ್ರಿಯೆಗಳು", th_vehicle: "ವಾಹನ",
      no_complaints: "ಯಾವುದೇ ದೂರುಗಳು ಕಂಡುಬಂದಿಲ್ಲ.", no_pending: "ಬಾಕಿ ದೂರುಗಳಿಲ್ಲ", no_resolved: "ಇನ್ನೂ ಯಾವುದೂ ಪರಿಹರಿಸಲಾಗಿಲ್ಲ",
      no_staff: "ಸಿಬ್ಬಂದಿ ಕಂಡುಬಂದಿಲ್ಲ", no_workers: "ಕಾರ್ಮಿಕರು ಕಂಡುಬಂದಿಲ್ಲ", no_data: "ಡೇಟಾ ಕಂಡುಬಂದಿಲ್ಲ", no_active_workers: "ಸಕ್ರಿಯ ಕಾರ್ಮಿಕರಿಲ್ಲ",
      all_staff: "ಎಲ್ಲ ಸಿಬ್ಬಂದಿ ಸದಸ್ಯರು", all_workers: "ಎಲ್ಲ ಕಾರ್ಮಿಕರು", all_submissions: "ಎಲ್ಲ ದೂರು ಸಲ್ಲಿಕೆಗಳು",
      total: "ಒಟ್ಟು", records: "ದಾಖಲೆಗಳು",
      in_progress: "ಪ್ರಗತಿಯಲ್ಲಿದೆ", resolve: "ಪರಿಹರಿಸಿ", edit: "ಸಂಪಾದಿಸಿ", delete: "ಅಳಿಸಿ", save_changes: "ಬದಲಾವಣೆಗಳನ್ನು ಉಳಿಸಿ",
      add_staff_header: "ಹೊಸ ಸಿಬ್ಬಂದಿ ಸದಸ್ಯರನ್ನು ಸೇರಿಸಿ", add_staff_btn: "ಸಿಬ್ಬಂದಿ ಸದಸ್ಯರನ್ನು ಸೇರಿಸಿ", edit_staff_title: "ಸಿಬ್ಬಂದಿ ಸಂಪಾದಿಸಿ", edit_staff_header: "ಸಿಬ್ಬಂದಿ ಸದಸ್ಯರನ್ನು ಸಂಪಾದಿಸಿ",
      field_full_name: "ಪೂರ್ಣ ಹೆಸರು *", new_password_label: "ಹೊಸ ಪಾಸ್‌ವರ್ಡ್",
      role_inspector: "ತಪಾಸಣಾಧಿಕಾರಿ", role_supervisor: "ಮೇಲ್ವಿಚಾರಕ", role_admin: "ನಿರ್ವಾಹಕ",
      add_worker: "➕ ಕಾರ್ಮಿಕ ಸೇರಿಸಿ", add_worker_header: "➕ ಹೊಸ ಕಾರ್ಮಿಕ ಸೇರಿಸಿ", add_worker_btn: "ಕಾರ್ಮಿಕ ಸೇರಿಸಿ", worker_name: "ಕಾರ್ಮಿಕ ಹೆಸರು",
      active_workers: "ಸಕ್ರಿಯ ಕಾರ್ಮಿಕರು", complaints_in_progress: "ಪ್ರಗತಿಯಲ್ಲಿರುವ ದೂರುಗಳು", active_workers_on_duty: "ಕರ್ತವ್ಯದ ಮೇಲಿರುವ ಸಕ್ರಿಯ ಕಾರ್ಮಿಕರು",
      worker_dashboard_title: "ಕಾರ್ಮಿಕ ಡ್ಯಾಶ್‌ಬೋರ್ಡ್", welcome_msg: "ಸ್ವಾಗತ! ಇಲ್ಲಿ ನಿಮ್ಮ ಪ್ರಸ್ತುತ ನಿಯೋಜನೆ ವಿವರಗಳಿವೆ.",
      worker_name_label: "ಕಾರ್ಮಿಕ ಹೆಸರು", status_active: "ಸಕ್ರಿಯ", worker_status_msg: "ನೀವು ಕರ್ತವ್ಯದ ಮೇಲಿದ್ದೀರಿ. ನಿಮ್ಮ ವಾರ್ಡ್‌ನಲ್ಲಿ ನಿಯೋಜಿಸಲಾದ ದೂರುಗಳಿಗಾಗಿ ನಿಮ್ಮ ಮೇಲ್ವಿಚಾರಕರೊಂದಿಗೆ ಪರಿಶೀಲಿಸಿ.",
      central_admin_title: "🏛️ ಕೇಂದ್ರ ನಿರ್ವಾಹಕ", central_dashboard_title: "ಕೇಂದ್ರ ಡ್ಯಾಶ್‌ಬೋರ್ಡ್ – ಎಲ್ಲ ನಗರಗಳು",
      supported_cities_label: "ಬೆಂಬಲಿತ ನಗರಗಳು", view_complaints: "ದೂರುಗಳನ್ನು ವೀಕ್ಷಿಸಿ →", no_cities: "ಇನ್ನೂ ಯಾವುದೇ ನಗರಗಳು ಸಂರಚಿಸಲಾಗಿಲ್ಲ.",
    }
  };
  // Merge extra keys into TRANSLATIONS
  ['en','hi','kn'].forEach(lang => {
    Object.assign(TRANSLATIONS[lang], extra[lang]);
  });
})();
