from flask import Blueprint, render_template, request, session, redirect, url_for, flash, jsonify
from utils.geo_utils import get_ward_data
from datetime import datetime
import os, uuid

user_bp = Blueprint('user', __name__)

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'webp', 'gif'}
MAX_IMAGES = 5

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def save_images(files):
    upload_folder = os.path.join(os.path.dirname(__file__), '..', 'static', 'uploads')
    os.makedirs(upload_folder, exist_ok=True)
    saved = []
    for file in files[:MAX_IMAGES]:
        if file and file.filename and allowed_file(file.filename):
            ext      = file.filename.rsplit('.', 1)[1].lower()
            filename = f"{uuid.uuid4().hex}.{ext}"
            file.save(os.path.join(upload_folder, filename))
            saved.append(filename)
    return saved


@user_bp.route('/form', methods=['GET', 'POST'])
def user_form():
    city     = session.get('detected_city', '')
    wards    = []
    coverage = None

    if city:
        ward_data = get_ward_data(city)
        wards     = ward_data.get('wards', [])
        coverage  = ward_data.get('found', False)

    if request.method == 'POST':
        name      = request.form.get('name', '').strip()
        phone     = request.form.get('phone', '').strip()
        ward_id   = request.form.get('ward_id', '').strip()
        complaint = request.form.get('complaint', '').strip()
        city_name = request.form.get('city', city).strip()
        latitude  = request.form.get('latitude', '') or None
        longitude = request.form.get('longitude', '') or None

        if not all([name, phone, ward_id, complaint]):
            flash('Please fill all required fields.', 'error')
            return redirect(url_for('user.user_form'))

        try:
            from app import get_db
            conn = get_db()
            cur  = conn.cursor()
            cur.execute(
                """INSERT INTO complaints
                   (name, phone, ward_id, city, complaint, latitude, longitude, created_at, status)
                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s, 'Pending')""",
                (name, phone, ward_id, city_name, complaint, latitude, longitude, datetime.now())
            )
            conn.commit()
            complaint_id = cur.lastrowid
            images = [f for f in request.files.getlist('images') if f and f.filename]
            if images:
                for fn in save_images(images):
                    cur.execute("INSERT INTO complaint_images (complaint_id, filename) VALUES (%s,%s)",
                                (complaint_id, fn))
                conn.commit()
            cur.close(); conn.close()
            flash(f'Complaint #{complaint_id} registered successfully!', 'success')
            return redirect(url_for('user.user_form'))
        except Exception as e:
            flash(f'Database error: {e}', 'error')

    return render_template('user/user_form.html', city=city, wards=wards, coverage=coverage)


@user_bp.route('/get-wards')
def get_wards_ajax():
    city_name = request.args.get('city', '').strip() or session.get('detected_city', '')
    if not city_name:
        return jsonify({"found": False, "error": "City not specified"}), 400
    return jsonify(get_ward_data(city_name))


@user_bp.route('/check-status')
def check_status():
    """Return complaint status JSON — verified by complaint_id + phone."""
    cid   = request.args.get('complaint_id', '').strip()
    phone = request.args.get('phone', '').strip()

    if not cid or not phone:
        return jsonify({"found": False, "message": "Complaint ID and phone number are required."})

    try:
        from app import get_db
        conn = get_db()
        cur  = conn.cursor()
        cur.execute(
            """SELECT c.complaint_id, c.name, c.phone, c.ward_id, c.city,
                      c.complaint, c.status, c.created_at, c.resolved_at,
                      w.ward_name
               FROM complaints c
               LEFT JOIN wards w ON c.ward_id = w.ward_id
               WHERE c.complaint_id = %s AND c.phone = %s""",
            (cid, phone)
        )
        row = cur.fetchone()

        # ── fetch the most recent proof image if complaint is Resolved ────────
        proof_image = None
        if row and row['status'] == 'Resolved':
            try:
                cur.execute(
                    "SELECT filename FROM resolved_images "
                    "WHERE complaint_id = %s ORDER BY image_id DESC LIMIT 1",
                    (row['complaint_id'],)
                )
                img_row = cur.fetchone()
                if img_row:
                    proof_image = img_row['filename']
            except Exception:
                pass   # resolved_images table might not exist on older DBs

        cur.close(); conn.close()

        if not row:
            return jsonify({"found": False,
                            "message": "No complaint found with that ID and phone number."})

        return jsonify({
            "found": True,
            "complaint": {
                "complaint_id": row['complaint_id'],
                "name":         row['name'],
                "ward_id":      row['ward_id'],
                "ward_name":    row.get('ward_name'),
                "city":         row['city'],
                "status":       row['status'],
                "created_at":   row['created_at'].strftime('%d %b %Y, %I:%M %p') if row['created_at'] else None,
                "resolved_at":  row['resolved_at'].strftime('%d %b %Y, %I:%M %p') if row['resolved_at'] else None,
                "proof_image":  proof_image,   # filename or null
            }
        })
    except Exception as e:
        return jsonify({"found": False, "message": f"Server error: {e}"})
